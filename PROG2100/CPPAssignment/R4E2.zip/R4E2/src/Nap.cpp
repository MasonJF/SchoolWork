/*
 * Nap.cpp
 *
 *  Created on: Oct. 25, 2019
 *      Author: piotr
 */

#include "Nap.h"

Nap::Nap(int n) :howLong_{n}
{
}

Nap::~Nap() {
	// TODO Auto-generated destructor stub
}

