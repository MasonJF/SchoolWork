/*
 * Treminate.cpp
 *
 *  Created on: Oct. 23, 2019
 *      Author: piotr
 */

#include "Terminate.h"

Terminate::Terminate() {
	// TODO Auto-generated constructor stub

}

Terminate::~Terminate() {
	// TODO Auto-generated destructor stub
}

