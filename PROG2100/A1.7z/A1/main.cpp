#include <iostream>
#include "Queue.h"


using namespace std;

int main() {
    Queue test = *new Queue();
    for (int i = 0; i < 20; ++i) {
        test.enqueue(new Plane(i));
    }

//    test.enqueue(new Plane);
//    test.dequeue();
//    test.dequeue();
//    test.enqueue(new Plane(0));
    for (int j = 0; j < 20; ++j) {
        cout << *test.inspect(j);
    }

    test.dequeue();
    test.dequeue();
    test.inspect(0);
    test.inspect(1);
    test.enqueue(new Plane(69));
    test.enqueue(new Plane(49));
    cout << *test.inspect(0);
    cout << *test.inspect(1);
    test.enqueue(new Plane(44));
    cout << *test.inspect(2);
    return 0;
}