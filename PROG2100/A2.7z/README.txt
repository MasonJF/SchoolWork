README

Airport Simulation V0.1
ENTER THE FOLLOWING INTO YOUR CONSOLE (WINDOWS)
g++ *.cpp -std=c++11 -Wall -o airportsim.exe

LINUX:

g++ *.cpp -std=c++11 -o airportsim

THEN

./airportsim(.exe)

The program should run and give you average times for (non randomized because I used Delay2) values.
