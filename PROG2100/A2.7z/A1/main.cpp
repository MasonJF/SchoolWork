#include <iostream>
#include "Airport.h"

using namespace std;

int main() {
    Airport *sim = new Airport();
    sim->runSimulation();
    return 0;
}