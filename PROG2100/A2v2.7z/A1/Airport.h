//
// Created by Mason Fraser on 09-Oct-19.
//

#ifndef A1_AIRPORT_H
#define A1_AIRPORT_H
#include "Queue.h"
#include "PlaneGenerator.h"
#include "Timer.h"
#include "Dispatcher.h"
#include "Delay.h"
#include <iostream>

class Airport {
public:
    void runSimulation();
};


#endif //A1_AIRPORT_H
