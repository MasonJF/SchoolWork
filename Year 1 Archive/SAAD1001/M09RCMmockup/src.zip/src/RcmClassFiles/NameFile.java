package RcmClassFiles;

import javax.swing.*;

public class NameFile {
    private JTextField addTextField;
    private JPanel panel1;
    private JButton addButton;
    private JTextField nameOfFileTextField;
    private JButton addButton1;
}
