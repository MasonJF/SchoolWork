1: Open terminal in source code location
2: Copy and paste >>>       gcc a2.c -o myprog -lm
3: Enjoy